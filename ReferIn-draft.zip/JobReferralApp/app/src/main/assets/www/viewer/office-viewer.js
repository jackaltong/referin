/*
 * office-viewer.js
 * ------------------------------------------------------------------
 * In-app document previewer for the ReferIn resume feature.
 *
 * This is a faithful web port of the "no_ad_office" Flutter viewer's
 * feature set — the exact parsing/rendering behaviours are preserved:
 *
 *   - PDF   : page-by-page canvas rendering + zoom            (pdfx  -> pdf.js)
 *   - DOCX  : rich text (bold/italic/underline/size/color),
 *             headings, lists, tables, alignment              (DocxParser -> mammoth.js)
 *   - DOC   : best-effort UTF-16LE text extraction w/ 兼容模式 banner
 *             (LegacyBinaryTextExtractor, ported 1:1 to JS below)
 *   - XLSX  : multi-sheet tab bar, frozen bold header row, grid (XlsxParser -> SheetJS)
 *   - XLS   : same grid via SheetJS + 兼容模式 banner          (XlsParser)
 *   - CSV   : delimiter auto-detect (, ; \t), grid            (CsvParser, ported below)
 *   - PPTX  : slide-by-slide navigation, text boxes w/ runs   (PptxParser, ported via JSZip)
 *   - PPT   : best-effort text extraction + 兼容模式 banner    (LegacyBinaryTextExtractor)
 *
 * Public API:
 *   OfficeViewer.openArrayBuffer(name, ext, arrayBuffer)
 *   OfficeViewer.openUrl(name, ext, url)     // for bundled sample assets
 *   OfficeViewer.kindOf(ext) -> 'pdf'|'word'|'sheet'|'ppt'|'unknown'
 */
(function (global) {
  'use strict';

  var VENDOR = 'vendor/';
  var pdfjsReady = false;

  /* ---------------- format helpers ---------------- */
  var EXT_KIND = {
    pdf: 'pdf',
    doc: 'word', docx: 'word',
    xls: 'sheet', xlsx: 'sheet', csv: 'sheet',
    ppt: 'ppt', pptx: 'ppt'
  };
  var LEGACY = { doc: true, xls: true, ppt: true };

  function kindOf(ext) {
    ext = (ext || '').toLowerCase().replace(/^\./, '');
    return EXT_KIND[ext] || 'unknown';
  }

  function extOf(name) {
    var m = /\.([a-z0-9]+)$/i.exec(name || '');
    return m ? m[1].toLowerCase() : '';
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ---------------- overlay scaffold ---------------- */
  function buildOverlay(title, subtitle) {
    var mask = document.createElement('div');
    mask.className = 'ov-mask';
    mask.innerHTML =
      '<div class="ov-shell">' +
        '<div class="ov-bar">' +
          '<div class="ov-back" role="button">‹</div>' +
          '<div class="ov-title"><div class="ov-name"></div><div class="ov-sub"></div></div>' +
          '<div class="ov-actions"></div>' +
        '</div>' +
        '<div class="ov-banner" style="display:none"></div>' +
        '<div class="ov-tabs" style="display:none"></div>' +
        '<div class="ov-body"></div>' +
        '<div class="ov-foot" style="display:none"></div>' +
      '</div>';
    mask.querySelector('.ov-name').textContent = title || '预览';
    mask.querySelector('.ov-sub').textContent = subtitle || '';
    document.body.appendChild(mask);
    requestAnimationFrame(function () { mask.classList.add('show'); });

    var api = {
      el: mask,
      body: mask.querySelector('.ov-body'),
      banner: mask.querySelector('.ov-banner'),
      tabs: mask.querySelector('.ov-tabs'),
      foot: mask.querySelector('.ov-foot'),
      actions: mask.querySelector('.ov-actions'),
      close: function () {
        mask.classList.remove('show');
        setTimeout(function () { mask.remove(); }, 240);
        OfficeViewer._current = null;
      },
      warn: function (msg) {
        api.banner.style.display = 'block';
        api.banner.innerHTML = '⚠️ ' + esc(msg);
      },
      loading: function (msg) {
        api.body.innerHTML = '<div class="ov-center"><div class="ov-spin"></div><div class="ov-hint">' + esc(msg || '正在解析…') + '</div></div>';
      },
      error: function (message, onRetry) {
        api.body.innerHTML =
          '<div class="ov-center">' +
            '<div style="font-size:46px">😵</div>' +
            '<div class="ov-err-t">无法打开该文件</div>' +
            '<div class="ov-err-d">' + esc(message) + '</div>' +
            '<button class="ov-retry">重试</button>' +
          '</div>';
        var btn = api.body.querySelector('.ov-retry');
        if (btn && onRetry) btn.onclick = onRetry;
      }
    };
    mask.querySelector('.ov-back').onclick = api.close;
    OfficeViewer._current = api;
    return api;
  }

  /* =====================================================================
   * LegacyBinaryTextExtractor — ported 1:1 from
   * no_ad_office/lib/parsers/legacy_binary_text_extractor.dart
   * ===================================================================== */
  var LegacyBinaryTextExtractor = {
    _minRunLength: 3,
    extractParagraphs: function (bytes) {
      var runs = [];
      var buf = [];
      var i = 0, len = bytes.length;
      while (i + 1 < len) {
        var unit = bytes[i] | (bytes[i + 1] << 8); // UTF-16LE code unit
        if (this._isLineBreakMarker(unit)) {
          buf.push('\n'); i += 2;
        } else if (this._isPrintableUnit(unit)) {
          buf.push(String.fromCharCode(unit)); i += 2;
        } else {
          if (buf.length >= this._minRunLength) runs.push(buf.join(''));
          buf = []; i += 1;
        }
      }
      if (buf.length >= this._minRunLength) runs.push(buf.join(''));

      var joined = runs.join('\n');
      var rawParas = joined.split('\n');
      var paragraphs = [];
      for (var k = 0; k < rawParas.length; k++) {
        var trimmed = rawParas[k].trim();
        if (!trimmed) continue;
        if (trimmed.length < 2) continue;
        if (this._looksLikeNoise(trimmed)) continue;
        paragraphs.push(trimmed);
      }
      return paragraphs;
    },
    _isLineBreakMarker: function (u) {
      return u === 0x0D || u === 0x0A || u === 0x0B || u === 0x07;
    },
    _isPrintableUnit: function (u) {
      if (u >= 0x20 && u < 0x7F) return true;
      if (u === 0x09) return true;
      if (u >= 0xA0 && u <= 0xFF) return true;
      if (u >= 0x3000 && u <= 0x303F) return true;
      if (u >= 0x3040 && u <= 0x30FF) return true;
      if (u >= 0x3400 && u <= 0x4DBF) return true;
      if (u >= 0x4E00 && u <= 0x9FFF) return true;
      if (u >= 0xAC00 && u <= 0xD7A3) return true;
      if (u >= 0xFF00 && u <= 0xFFEF) return true;
      if (u >= 0x0100 && u <= 0x024F) return true;
      if (u >= 0x0370 && u <= 0x03FF) return true;
      if (u >= 0x0400 && u <= 0x04FF) return true;
      return false;
    },
    _looksLikeNoise: function (s) {
      var meaningful = 0;
      for (var idx = 0; idx < s.length; idx++) {
        var r = s.charCodeAt(idx);
        var isAsciiLetter = (r >= 65 && r <= 90) || (r >= 97 && r <= 122);
        var isNonAscii = r > 0x7F;
        if (isAsciiLetter || isNonAscii) meaningful++;
      }
      var ratio = meaningful / s.length;
      if (s.length <= 4 && meaningful === 0) return true;
      if (ratio < 0.15 && s.length < 8) return true;
      return false;
    }
  };

  /* =====================================================================
   * CSV parser — ported from no_ad_office/lib/parsers/csv_parser.dart
   * (delimiter auto-detect: , ; \t) with quoted-field handling.
   * ===================================================================== */
  function parseCsv(text) {
    if (!text) throw new Error('CSV 文件内容为空');
    var normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    var firstLine = '';
    var lines = normalized.split('\n');
    for (var i = 0; i < lines.length; i++) { if (lines[i].length) { firstLine = lines[i]; break; } }
    var delim = detectDelimiter(firstLine);
    var rows = csvDecode(normalized, delim);
    rows = rows.filter(function (r) { return r.length && !(r.length === 1 && r[0] === ''); });
    if (!rows.length) throw new Error('CSV 文件不包含任何数据行');
    return [{ name: 'CSV', rows: rows }];
  }
  function detectDelimiter(sample) {
    var counts = {
      ',': (sample.split(',').length - 1),
      ';': (sample.split(';').length - 1),
      '\t': (sample.split('\t').length - 1)
    };
    var best = ',', bestCount = -1;
    Object.keys(counts).forEach(function (d) { if (counts[d] > bestCount) { bestCount = counts[d]; best = d; } });
    return bestCount > 0 ? best : ',';
  }
  function csvDecode(text, delim) {
    var rows = [], field = '', row = [], inQ = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (inQ) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; }
          else inQ = false;
        } else field += c;
      } else {
        if (c === '"') inQ = true;
        else if (c === delim) { row.push(field); field = ''; }
        else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
        else field += c;
      }
    }
    if (field.length || row.length) { row.push(field); rows.push(row); }
    return rows;
  }

  /* =====================================================================
   * PPTX parser — ported from no_ad_office/lib/parsers/pptx_parser.dart
   * (slide order, text boxes, runs with bold/italic/underline/size/color)
   * ===================================================================== */
  var A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main';
  function parsePptx(zip) {
    var slideNames = Object.keys(zip.files).filter(function (n) {
      return /^ppt\/slides\/slide\d+\.xml$/.test(n);
    });
    if (!slideNames.length) throw new Error('未在该 pptx 文件中找到任何幻灯片 (ppt/slides/slideN.xml)');
    slideNames.sort(function (a, b) {
      var na = parseInt(/(\d+)/.exec(a)[1], 10);
      var nb = parseInt(/(\d+)/.exec(b)[1], 10);
      return na - nb;
    });
    var parser = new DOMParser();
    var slides = [];
    return slideNames.reduce(function (p, name, idx) {
      return p.then(function () {
        return zip.files[name].async('string').then(function (xmlStr) {
          var doc;
          try { doc = parser.parseFromString(xmlStr, 'application/xml'); }
          catch (e) { return; }
          var boxes = extractTextBoxes(doc);
          slides.push({ index: idx + 1, textBoxes: boxes });
        });
      });
    }, Promise.resolve()).then(function () { return slides; });
  }
  function extractTextBoxes(doc) {
    var boxes = [];
    var sps = doc.getElementsByTagNameNS('http://schemas.openxmlformats.org/presentationml/2006/main', 'sp');
    for (var i = 0; i < sps.length; i++) {
      var box = spToBox(sps[i]);
      if (box) boxes.push(box);
    }
    return boxes;
  }
  function spToBox(sp) {
    var txBodies = sp.getElementsByTagNameNS(A_NS, 'txBody');
    // presentationml txBody uses p: namespace wrapper but a: paragraphs
    var txBody = null;
    var children = sp.childNodes;
    for (var i = 0; i < children.length; i++) {
      if (children[i].localName === 'txBody') { txBody = children[i]; break; }
    }
    if (!txBody) return null;
    var paras = [];
    var ps = txBody.getElementsByTagNameNS(A_NS, 'p');
    for (var j = 0; j < ps.length; j++) paras.push(parseAParagraph(ps[j]));
    var hasText = paras.some(function (pp) { return plainOf(pp).trim().length; });
    return hasText ? { paragraphs: paras } : null;
  }
  function parseAParagraph(aP) {
    var align = 'left';
    var pPr = firstChildNS(aP, A_NS, 'pPr');
    var indentLevel = 0, isListItem = false;
    if (pPr) {
      var algn = pPr.getAttribute('algn');
      if (algn === 'ctr') align = 'center';
      else if (algn === 'r') align = 'right';
      else if (algn === 'just') align = 'justify';
      var lvl = pPr.getAttribute('lvl');
      indentLevel = parseInt(lvl || '0', 10) || 0;
      isListItem = !!firstChildNS(pPr, A_NS, 'buChar') || !!firstChildNS(pPr, A_NS, 'buAutoNum');
    }
    var runs = [];
    var rs = aP.getElementsByTagNameNS(A_NS, 'r');
    for (var i = 0; i < rs.length; i++) {
      var r = rs[i];
      var tEl = firstChildNS(r, A_NS, 't');
      var text = tEl ? tEl.textContent : '';
      var rPr = firstChildNS(r, A_NS, 'rPr');
      var bold = false, italic = false, underline = false, sizePt = null, color = null;
      if (rPr) {
        bold = rPr.getAttribute('b') === '1';
        italic = rPr.getAttribute('i') === '1';
        var u = rPr.getAttribute('u');
        underline = u != null && u !== 'none';
        var sz = rPr.getAttribute('sz');
        if (sz != null) { var h = parseInt(sz, 10); if (!isNaN(h)) sizePt = h / 100.0; }
        var solid = firstChildNS(rPr, A_NS, 'solidFill');
        var srgb = solid ? firstChildNS(solid, A_NS, 'srgbClr') : null;
        if (srgb && srgb.getAttribute('val')) color = srgb.getAttribute('val');
      }
      runs.push({ text: text, bold: bold, italic: italic, underline: underline, sizePt: sizePt, color: color });
    }
    if (!runs.length) {
      var brs = aP.getElementsByTagNameNS(A_NS, 'br');
      if (brs.length) runs.push({ text: '\n' });
    }
    return { runs: runs, align: align, indentLevel: indentLevel, isListItem: isListItem };
  }
  function firstChildNS(node, ns, local) {
    var c = node.childNodes;
    for (var i = 0; i < c.length; i++) {
      if (c[i].nodeType === 1 && c[i].localName === local) return c[i];
    }
    return null;
  }
  function plainOf(para) { return (para.runs || []).map(function (r) { return r.text || ''; }).join(''); }

  function runsToHtml(para) {
    var html = (para.runs || []).map(function (run) {
      var style = '';
      if (run.bold) style += 'font-weight:600;';
      if (run.italic) style += 'font-style:italic;';
      if (run.underline) style += 'text-decoration:underline;';
      if (run.sizePt) style += 'font-size:' + Math.max(10, Math.min(40, run.sizePt)) + 'px;';
      if (run.color) style += 'color:#' + run.color + ';';
      var t = esc(run.text).replace(/\n/g, '<br>').replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
      return '<span style="' + style + '">' + t + '</span>';
    }).join('');
    var pad = para.indentLevel ? ('padding-left:' + (para.indentLevel * 18) + 'px;') : '';
    var bullet = para.isListItem ? '• ' : '';
    return '<div style="text-align:' + para.align + ';' + pad + '">' + bullet + (html || '&nbsp;') + '</div>';
  }

  /* =====================================================================
   * Renderers
   * ===================================================================== */
  function renderSheets(api, sheets) {
    if (!sheets.length) { api.error('未能解析出任何工作表内容'); return; }
    var active = 0;
    function draw() {
      var sheet = sheets[active];
      var rows = sheet.rows || [];
      if (!rows.length) { api.body.innerHTML = '<div class="ov-center"><div class="ov-hint">该工作表没有数据</div></div>'; return; }
      var maxCols = rows.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
      var html = '<div class="ov-sheet-wrap"><table class="ov-sheet">';
      for (var r = 0; r < rows.length; r++) {
        html += '<tr class="' + (r === 0 ? 'head' : '') + '">';
        html += '<td class="rownum">' + (r + 1) + '</td>';
        for (var c = 0; c < maxCols; c++) {
          html += '<td>' + esc(rows[r][c] != null ? rows[r][c] : '') + '</td>';
        }
        html += '</tr>';
      }
      html += '</table></div>';
      api.body.innerHTML = html;
    }
    if (sheets.length > 1) {
      api.tabs.style.display = 'flex';
      api.tabs.innerHTML = sheets.map(function (s, i) {
        return '<div class="ov-tab' + (i === 0 ? ' on' : '') + '" data-i="' + i + '">' + esc(s.name) + '</div>';
      }).join('');
      api.tabs.querySelectorAll('.ov-tab').forEach(function (t) {
        t.onclick = function () {
          active = parseInt(t.dataset.i, 10);
          api.tabs.querySelectorAll('.ov-tab').forEach(function (x) { x.classList.remove('on'); });
          t.classList.add('on');
          draw();
        };
      });
    }
    draw();
  }

  function renderSlides(api, slides) {
    if (!slides.length) { api.error('该演示文稿没有任何幻灯片'); return; }
    var idx = 0;
    api.foot.style.display = 'flex';
    function draw() {
      var slide = slides[idx];
      var inner = (slide.textBoxes || []).map(function (box) {
        return '<div class="ov-slide-box">' + box.paragraphs.map(runsToHtml).join('') + '</div>';
      }).join('');
      if (!inner) inner = '<div class="ov-hint" style="text-align:center;padding:40px">（本页为图片/图形内容，无文本）</div>';
      api.body.innerHTML =
        '<div class="ov-slide-scroll"><div class="ov-slide"><div class="ov-slide-no">第 ' + (idx + 1) + ' / ' + slides.length + ' 页</div>' + inner + '</div></div>';
      api.foot.innerHTML =
        '<button class="ov-nav" ' + (idx === 0 ? 'disabled' : '') + ' data-d="-1">‹ 上一页</button>' +
        '<div class="ov-page">' + (idx + 1) + ' / ' + slides.length + '</div>' +
        '<button class="ov-nav" ' + (idx === slides.length - 1 ? 'disabled' : '') + ' data-d="1">下一页 ›</button>';
      api.foot.querySelectorAll('.ov-nav').forEach(function (b) {
        b.onclick = function () {
          var d = parseInt(b.dataset.d, 10);
          idx = Math.max(0, Math.min(slides.length - 1, idx + d));
          draw();
        };
      });
    }
    draw();
  }

  function renderWordHtml(api, html) {
    api.body.innerHTML = '<div class="ov-doc">' + html + '</div>';
  }

  function renderTextParagraphs(api, paras) {
    var html = paras.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('');
    api.body.innerHTML = '<div class="ov-doc ov-doc-plain">' + (html || '<p class="ov-hint">（未识别到可显示的文本内容）</p>') + '</div>';
  }

  function ensurePdfjs() {
    if (pdfjsReady) return Promise.resolve();
    return loadScript(VENDOR + 'pdf.min.js').then(function () {
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = VENDOR + 'pdf.worker.min.js';
      pdfjsReady = true;
    });
  }

  function ensureMammoth() {
    if (global.mammoth) return Promise.resolve();
    return loadScript(VENDOR + 'mammoth.browser.min.js');
  }

  function ensureXLSX() {
    if (global.XLSX) return Promise.resolve();
    return loadScript(VENDOR + 'xlsx.full.min.js');
  }

  function ensureJSZip() {
    if (global.JSZip) return Promise.resolve();
    return loadScript(VENDOR + 'jszip.min.js');
  }

  function renderPdf(api, data) {
    ensurePdfjs().then(function () {
      return global.pdfjsLib.getDocument({ data: data }).promise;
    }).then(function (pdf) {
      api.body.innerHTML = '<div class="ov-pdf" id="ovPdf"></div>';
      var cont = api.body.querySelector('#ovPdf');
      var pageCount = pdf.numPages;
      var dpr = global.devicePixelRatio || 1;
      var zoom = 1;              // 用户缩放倍数：1 = 100%（默认适配屏宽）
      var MIN = 0.5, MAX = 4;
      api.actions.innerHTML = '<div class="ov-zoom"><span class="zo" data-z="-1">－</span><span class="zl">100%</span><span class="zo" data-z="1">＋</span></div>';
      var zl = api.actions.querySelector('.zl');
      var renderToken = 0;

      function renderAll() {
        var myToken = ++renderToken;   // 快速连点缩放时，作废旧的渲染链，避免重复追加
        cont.innerHTML = '';
        zl.textContent = Math.round(zoom * 100) + '%';
        // 以容器可用宽度为「适配屏宽」基准，再乘以用户缩放倍数
        var contW = cont.clientWidth || api.body.clientWidth || global.innerWidth || 360;
        var chain = Promise.resolve();
        for (var n = 1; n <= pageCount; n++) {
          (function (num) {
            chain = chain.then(function () {
              if (myToken !== renderToken) return;
              return pdf.getPage(num).then(function (page) {
                if (myToken !== renderToken) return;
                var base = page.getViewport({ scale: 1 });
                // 100% 时按页面原始宽高比铺满可用宽度（保留少量留白），缩放时等比放大/缩小
                var fitScale = (contW * 0.96) / base.width;
                var vp = page.getViewport({ scale: fitScale * zoom });
                var cssW = vp.width, cssH = vp.height;
                var canvas = document.createElement('canvas');
                canvas.className = 'ov-pdf-page';
                var ctx = canvas.getContext('2d');
                // backing store 按 devicePixelRatio 放大 → 清晰不模糊
                canvas.width = Math.round(cssW * dpr);
                canvas.height = Math.round(cssH * dpr);
                // 显式锁定 CSS 宽高（同一 viewport 派生）→ 宽高比恒定，布局保真
                canvas.style.width = Math.round(cssW) + 'px';
                canvas.style.height = Math.round(cssH) + 'px';
                ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                cont.appendChild(canvas);
                return page.render({ canvasContext: ctx, viewport: vp }).promise;
              });
            });
          })(n);
        }
        return chain;
      }
      api.actions.querySelectorAll('.zo').forEach(function (b) {
        b.onclick = function () {
          var d = parseInt(b.dataset.z, 10);
          zoom = Math.max(MIN, Math.min(MAX, Math.round((zoom + d * 0.25) * 100) / 100));
          renderAll();
        };
      });
      api.foot.style.display = 'flex';
      api.foot.innerHTML = '<div class="ov-page">共 ' + pageCount + ' 页 · 可上下滚动查看</div>';
      renderAll();
    }).catch(function (e) {
      api.error('PDF 解析失败：' + (e && e.message ? e.message : e), null);
    });
  }

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      if (loadScript._cache && loadScript._cache[src]) { resolve(); return; }
      var s = document.createElement('script');
      s.src = src;
      s.onload = function () { (loadScript._cache = loadScript._cache || {})[src] = true; resolve(); };
      s.onerror = function () { reject(new Error('资源加载失败: ' + src)); };
      document.head.appendChild(s);
    });
  }

  /* =====================================================================
   * Dispatch
   * ===================================================================== */
  function openArrayBuffer(name, ext, buf) {
    ext = (ext || extOf(name)).toLowerCase();
    var kind = kindOf(ext);
    var api = buildOverlay(name, kindLabel(ext));
    api.loading('正在解析 ' + ext.toUpperCase() + ' 文档…');

    setTimeout(function () {
      try {
        if (kind === 'pdf') {
          renderPdf(api, new Uint8Array(buf));
        } else if (kind === 'word') {
          if (ext === 'docx') {
            ensureMammoth().then(function () {
              return global.mammoth.convertToHtml({ arrayBuffer: buf });
            })
              .then(function (res) { renderWordHtml(api, res.value || '<p class="ov-hint">（空文档）</p>'); })
              .catch(function (e) { api.error('Word 解析失败：' + e.message); });
          } else {
            api.warn('兼容模式预览：旧版 .doc 为二进制格式，已尽力还原文本内容，可能不含排版/表格/图片。');
            var paras = LegacyBinaryTextExtractor.extractParagraphs(new Uint8Array(buf));
            renderTextParagraphs(api, paras);
          }
        } else if (kind === 'sheet') {
          if (ext === 'csv') {
            var text = decodeText(buf);
            renderSheets(api, parseCsv(text));
          } else {
            if (ext === 'xls') api.warn('兼容模式预览：旧版 .xls 二进制格式，已解析单元格数据，样式/公式可能不完整。');
            ensureXLSX().then(function () {
              var wb = global.XLSX.read(new Uint8Array(buf), { type: 'array' });
              var sheets = wb.SheetNames.map(function (nm) {
                var ws = wb.Sheets[nm];
                var aoa = global.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: '' });
                return { name: nm, rows: aoa };
              });
              renderSheets(api, sheets);
            }).catch(function (e) { api.error('Excel 解析失败：' + e.message); });
          }
        } else if (kind === 'ppt') {
          if (ext === 'pptx') {
            loadScript(VENDOR + 'jszip.min.js').then(function () {
              return global.JSZip.loadAsync(buf);
            }).then(function (zip) {
              return parsePptx(zip);
            }).then(function (slides) {
              renderSlides(api, slides);
            }).catch(function (e) { api.error('PPT 解析失败：' + e.message); });
          } else {
            api.warn('兼容模式预览：旧版 .ppt 二进制格式，已尽力还原文本内容，图形/排版可能缺失。');
            var pptParas = LegacyBinaryTextExtractor.extractParagraphs(new Uint8Array(buf));
            renderTextParagraphs(api, pptParas);
          }
        } else {
          api.error('暂不支持该文件格式。当前支持 PDF、Word（doc/docx）、Excel（xls/xlsx）、CSV、PowerPoint（ppt/pptx）。');
        }
      } catch (e) {
        api.error((e && e.message) ? e.message : String(e));
      }
    }, 80);
    return api;
  }

  function openUrl(name, ext, url) {
    ext = (ext || extOf(name) || extOf(url)).toLowerCase();
    var api = buildOverlay(name, kindLabel(ext));
    api.loading('正在载入示例文件…');
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('文件读取失败 (' + r.status + ')');
      return r.arrayBuffer();
    }).then(function (buf) {
      api.close();
      openArrayBuffer(name, ext, buf);
    }).catch(function (e) {
      api.error('无法读取文件：' + e.message, function () { api.close(); openUrl(name, ext, url); });
    });
  }

  function decodeText(buf) {
    try { return new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(buf)); }
    catch (e) { return new TextDecoder('latin1').decode(new Uint8Array(buf)); }
  }

  function kindLabel(ext) {
    var map = {
      pdf: 'PDF 文档', doc: 'Word 文档（兼容）', docx: 'Word 文档',
      xls: 'Excel 表格（兼容）', xlsx: 'Excel 表格', csv: 'CSV 表格',
      ppt: 'PPT 演示（兼容）', pptx: 'PPT 演示'
    };
    return map[ext] || '文档';
  }

  var OfficeViewer = {
    _current: null,
    openArrayBuffer: openArrayBuffer,
    openUrl: openUrl,
    kindOf: kindOf,
    extOf: extOf,
    isLegacy: function (ext) { return !!LEGACY[(ext || '').toLowerCase()]; },
    closeCurrent: function () { if (OfficeViewer._current) { OfficeViewer._current.close(); return true; } return false; }
  };
  global.OfficeViewer = OfficeViewer;
})(window);
