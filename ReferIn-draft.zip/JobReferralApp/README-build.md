# ReferIn 内推 · Android 源码工程

一个以 WebView 为壳、承载 H5 单页应用的混合式 Android 求职内推 APP。

- 应用名：ReferIn 内推
- 包名：`com.referin.app`
- minSdk 24 / targetSdk 34 / compileSdk 34

## 目录结构

```
JobReferralApp/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/referin/app/MainActivity.java   # WebView 壳 + 文件选择 + 返回键代理
│       └── assets/www/                              # H5 单页应用
│           ├── index.html                           # 主入口（求职/HR/企业、小游戏、文件预览）
│           ├── viewer/office-viewer.js              # 文档预览模块（PDF/Word/Excel/PPT/CSV）
│           ├── viewer/office-viewer.css
│           ├── game/sanguo.html                     # 付费用户小游戏
│           └── vendor/                              # pdf.js / mammoth / xlsx / jszip 离线库
└── README-build.md
```

## 环境要求

- JDK 17
- Android SDK（compileSdk 34、build-tools 34.x）
- Gradle 8.7（或使用工程自带 wrapper）

## 配置 SDK 路径

本源码包**不含** `local.properties`（其中记录的是本机 SDK 绝对路径）。请在 `JobReferralApp/` 根目录新建 `local.properties`：

```
sdk.dir=/你的/Android/SDK/路径
```

也可以通过环境变量 `ANDROID_HOME` / `ANDROID_SDK_ROOT` 指定。

## 构建命令

```bash
cd JobReferralApp

# Debug 包
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk

# Release 包
./gradlew assembleRelease
# 产物：app/build/outputs/apk/release/app-release.apk
```

## 功能说明

- **身份切换**：首页左上角 chip 可在 求职者 / HR / 企业 之间切换，各自对应工作台。
- **小游戏（付费专属）**：付费用户在首页下拉进入三国小游戏；免费用户不可见入口。
- **简历上传与预览**：支持 PDF / Word 上传并在应用内预览；上传/打开 Excel、PPT、CSV 时会提示"别调皮啦~"（后置触发），但仍可正常打开查看。
- **文档预览能力**：PDF（pdf.js）、DOCX（mammoth）、DOC/PPT（二进制文本抽取）、XLS/XLSX（SheetJS）、CSV（分隔符自动识别）、PPTX（JSZip 解析）。所有依赖库均已离线打包在 `assets/www/vendor/`，无需联网。
